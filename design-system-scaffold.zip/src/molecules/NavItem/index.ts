// NavItem component placeholder
export const NavItem = () => null; 