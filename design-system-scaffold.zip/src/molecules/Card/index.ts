// Card component placeholder
export const Card = () => null; 