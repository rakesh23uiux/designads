// Dropdown component placeholder
export const Dropdown = () => null; 