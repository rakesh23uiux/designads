// Layouts placeholder exports
export const PageLayout = () => null;
export const DashboardLayout = () => null;
export const AuthLayout = () => null; 