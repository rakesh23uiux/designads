// Pages placeholder exports
export const HomePage = () => null;
export const LoginPage = () => null; 