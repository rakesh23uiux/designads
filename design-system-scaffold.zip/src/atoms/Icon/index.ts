// Icon component placeholder
export const Icon = () => null; 