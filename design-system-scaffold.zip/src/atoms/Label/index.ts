// Label component placeholder
export const Label = () => null; 