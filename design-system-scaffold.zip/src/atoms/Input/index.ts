// Input component placeholder
export const Input = () => null; 