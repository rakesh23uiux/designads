// Badge component placeholder
export const Badge = () => null; 