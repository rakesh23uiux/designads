// Avatar component placeholder
export const Avatar = () => null; 